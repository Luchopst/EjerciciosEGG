/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entidades.Pais;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author User
 */
public class paisService {
    private Scanner input = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
    HashSet<Pais> paises = new HashSet();
    TreeSet<Pais> treePaises = new TreeSet<>(); // utilizar variable de clase
    // ...

    public void CrearPais() {
        do {
            System.out.println("Ingrese el Pais");
            paises.add(new Pais(input.next()));
            treePaises = new TreeSet<>(paises); // actualizar variable de clase
            System.out.println("Desea Ingresar Otro Pais?? Responda S/N");
            if (input.next().equalsIgnoreCase("n")) {
                System.out.println("Hasta la Vista BABY");
                break;
            }
        } while (true);
         System.out.println(treePaises); // imprimir variable de clase
    }
        
    

    public void Mostrar() {
        for (Pais paisAux : paises) {
            Pais p = paisAux;
            System.out.println(" Los Paises en HashSet Son: " + p.toString());
           
        }
    }

 
}


