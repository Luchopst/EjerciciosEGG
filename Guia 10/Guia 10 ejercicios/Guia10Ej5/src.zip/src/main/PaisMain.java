/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import service.paisService;

/**
 *
 * @author User
 */
public class PaisMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        paisService ps = new paisService();
        ps.CrearPais();
        ps.Mostrar();
    
        }
    }


